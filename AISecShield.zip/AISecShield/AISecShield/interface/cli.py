"""
Command-line interface for AISecShield.
"""
import argparse
import json
import logging
import sys
from typing import Dict, List, Optional, Any

from ..core.module_manager import ModuleManager
from ..modules.prompt_injection.scanner import PromptInjectionScanner
from ..modules.model_robustness.scanner import ModelRobustnessScanner
from ..modules.privacy_scanner.scanner import PrivacyScanner
from ..modules.cross_model_analyzer.scanner import CrossModelAnalyzer
from ..modules.mlops_auditor.scanner import MLOpsAuditor

def setup_logging(verbosity: int) -> None:
    """
    Configure logging based on verbosity level.
    
    Args:
        verbosity: Verbosity level (0-3)
    """
    log_levels = {
        0: logging.WARNING,
        1: logging.INFO,
        2: logging.DEBUG,
        3: logging.DEBUG
    }
    
    log_level = log_levels.get(verbosity, logging.INFO)
    
    logging.basicConfig(
        level=log_level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Set super verbose debug logging if verbosity is 3
    if verbosity >= 3:
        logging.getLogger().setLevel(logging.DEBUG)
        # Enable debug logging for all libraries
        for logger_name in logging.root.manager.loggerDict:
            logging.getLogger(logger_name).setLevel(logging.DEBUG)

def register_modules(manager: ModuleManager) -> None:
    """
    Register all available scanning modules.
    
    Args:
        manager: Module manager instance
    """
    manager.register_module("prompt_injection", PromptInjectionScanner)
    manager.register_module("model_robustness", ModelRobustnessScanner)
    manager.register_module("privacy", PrivacyScanner)
    manager.register_module("cross_model", CrossModelAnalyzer)
    manager.register_module("mlops", MLOpsAuditor)

def save_report(report: Dict[str, Any], output_file: str) -> None:
    """
    Save scan report to file.
    
    Args:
        report: Scan results to save
        output_file: Path to output file
    """
    with open(output_file, 'w') as f:
        json.dump(report, f, indent=2)
    
    print(f"Report saved to {output_file}")

def display_summary(report: Dict[str, Any]) -> None:
    """
    Display a summary of scan results.
    
    Args:
        report: Scan results to summarize
    """
    print("\n===== AISecShield Scan Summary =====")
    
    # Print modules run
    modules_run = [k for k in report.get("results", {}).keys()]
    print(f"Modules run: {', '.join(modules_run)}")
    
    # Count vulnerabilities by severity
    severities = {"critical": 0, "high": 0, "medium": 0, "low": 0}
    
    for module, result in report.get("results", {}).items():
        for vuln in result.get("vulnerabilities", []):
            severity = vuln.get("severity", "unknown")
            if severity in severities:
                severities[severity] += 1
    
    # Print vulnerability counts
    print("\nVulnerabilities found:")
    for severity, count in severities.items():
        print(f"  {severity.upper()}: {count}")
    
    # Print overall risk assessment
    total_issues = sum(severities.values())
    risk_level = "LOW"
    if severities["critical"] > 0 or severities["high"] >= 3:
        risk_level = "CRITICAL"
    elif severities["high"] > 0 or severities["medium"] >= 5:
        risk_level = "HIGH"
    elif severities["medium"] > 0:
        risk_level = "MEDIUM"
    
    print(f"\nTotal issues: {total_issues}")
    print(f"Overall risk level: {risk_level}")
    
    # Print next steps
    print("\nNext steps:")
    if total_issues > 0:
        print("  - Review the full report for detailed findings")
        print("  - Address CRITICAL and HIGH severity issues first")
        if severities["critical"] > 0:
            print("  - Consider taking the system offline until CRITICAL issues are resolved")
    else:
        print("  - No issues found! Continue monitoring for new vulnerabilities")
    
    print("\nFor detailed information, see the full report.")
    print("=====================================")

def main() -> None:
    """
    Main entry point for the CLI application.
    """
    parser = argparse.ArgumentParser(
        description="AISecShield - Comprehensive AI Security Testing Framework",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    
    # General options
    parser.add_argument("--target", help="Target API URL or model path")
    parser.add_argument("--api-key", help="API key for authenticated requests")
    parser.add_argument("--output", default="aisecshield_report.json", help="Output file for the report")
    parser.add_argument("-v", "--verbosity", action="count", default=0, help="Increase verbosity (can use multiple times)")
    
    # Module selection
    parser.add_argument(
        "--modules", 
        nargs="+", 
        choices=["all", "prompt_injection", "model_robustness", "privacy", "cross_model", "mlops"],
        default=["all"],
        help="Modules to run"
    )
    
    # Module-specific options
    prompt_group = parser.add_argument_group("Prompt Injection Scanner Options")
    prompt_group.add_argument("--prompt-target", help="Target API for prompt injection testing")
    
    robustness_group = parser.add_argument_group("Model Robustness Scanner Options")
    robustness_group.add_argument("--model-path", help="Path to model for robustness testing")
    robustness_group.add_argument("--test-data", help="Path to test data for robustness testing")
    
    privacy_group = parser.add_argument_group("Privacy Scanner Options")
    privacy_group.add_argument("--privacy-target", help="Target API for privacy testing")
    
    mlops_group = parser.add_argument_group("MLOps Auditor Options")
    mlops_group.add_argument("--pipeline-config", help="Path to MLOps pipeline configuration")
    mlops_group.add_argument("--codebase-path", help="Path to codebase for static analysis")
    
    args = parser.parse_args()
    
    # Setup logging
    setup_logging(args.verbosity)
    
    # Create module manager
    manager = ModuleManager()
    register_modules(manager)
    
    # Show available modules if requested
    if args.verbosity > 0:
        print(f"Available modules: {', '.join(manager.get_available_modules())}")
    
    # Validate inputs
    if "all" in args.modules or "prompt_injection" in args.modules:
        if not args.target and not args.prompt_target:
            print("Error: --target or --prompt-target is required for prompt injection testing")
            sys.exit(1)
    
    # Run selected modules
    if "all" in args.modules:
        # Run all modules with appropriate configuration
        results = {}
        
        # Prompt Injection
        if args.target or args.prompt_target:
            target_api = args.prompt_target or args.target
            try:
                results["prompt_injection"] = manager.run_module(
                    "prompt_injection",
                    target_api=target_api,
                    api_key=args.api_key
                )
            except Exception as e:
                print(f"Error running prompt_injection module: {e}")
        
        # Add more modules here with appropriate configuration
        
    else:
        # Run specific modules
        results = {}
        for module in args.modules:
            try:
                # Configure module-specific parameters
                if module == "prompt_injection":
                    target_api = args.prompt_target or args.target
                    results[module] = manager.run_module(
                        module,
                        target_api=target_api,
                        api_key=args.api_key
                    )
                # Add more module-specific configurations here
                else:
                    print(f"Module {module} not yet implemented in CLI")
            except Exception as e:
                print(f"Error running {module} module: {e}")
    
    # Generate report
    report = {
        "summary": {
            "total_modules": len(manager.get_available_modules()),
            "modules_run": len(results),
        },
        "results": results
    }
    
    # Save report
    save_report(report, args.output)
    
    # Display summary
    display_summary(report)

if __name__ == "__main__":
    main()
