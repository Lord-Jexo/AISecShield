// AISecShield main JavaScript file

// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Handle "All Modules" checkbox if present
    const allModulesCheckbox = document.getElementById('all_modules');
    if (allModulesCheckbox) {
        allModulesCheckbox.addEventListener('change', function() {
            const moduleCheckboxes = document.querySelectorAll('.module-checkbox');
            moduleCheckboxes.forEach(function(checkbox) {
                checkbox.checked = allModulesCheckbox.checked;
                checkbox.disabled = allModulesCheckbox.checked;
            });
        });
    }
    
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Add timestamp to newly created scans
    const scanForm = document.querySelector('form[action="/scan"]');
    if (scanForm) {
        scanForm.addEventListener('submit', function() {
            const now = new Date();
            const hiddenInput = document.createElement('input');
            hiddenInput.type = 'hidden';
            hiddenInput.name = 'timestamp';
            hiddenInput.value = now.toISOString();
            scanForm.appendChild(hiddenInput);
        });
    }
});

// Function to toggle vulnerability details
function toggleDetails(id) {
    const detailsElement = document.getElementById(id);
    if (detailsElement) {
        if (detailsElement.style.display === 'none') {
            detailsElement.style.display = 'block';
        } else {
            detailsElement.style.display = 'none';
        }
    }
}
