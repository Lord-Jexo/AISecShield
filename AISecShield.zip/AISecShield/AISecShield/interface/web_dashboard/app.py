"""
Web dashboard for AISecShield.
"""
from flask import Flask, render_template, request, jsonify, redirect, url_for
import logging
import json
import os
import datetime
from typing import Dict, Any

from ...core.module_manager import ModuleManager
from ...modules.prompt_injection.scanner import PromptInjectionScanner
from ...modules.model_robustness.scanner import ModelRobustnessScanner
from ...modules.privacy_scanner.scanner import PrivacyScanner
from ...modules.cross_model_analyzer.scanner import CrossModelAnalyzer
from ...modules.mlops_auditor.scanner import MLOpsAuditor

# Create Flask app
app = Flask(__name__)

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Create and configure module manager
manager = ModuleManager()

# Register modules
manager.register_module("prompt_injection", PromptInjectionScanner)
manager.register_module("model_robustness", ModelRobustnessScanner)
manager.register_module("privacy", PrivacyScanner)
manager.register_module("cross_model", CrossModelAnalyzer)
manager.register_module("mlops", MLOpsAuditor)

# Store scan history
scan_history = []

# Add json filter for templates
@app.template_filter('tojson')
def to_json(value, indent=None):
    return json.dumps(value, indent=indent)

@app.route('/')
def index():
    """Render the dashboard homepage."""
    return render_template('index.html')

@app.route('/modules')
def modules():
    """Render the modules page."""
    available_modules = manager.get_available_modules()
    return render_template('modules.html', modules=available_modules)

@app.route('/scan', methods=['GET', 'POST'])
def scan():
    """Handle scan requests."""
    if request.method == 'GET':
        # Get module from query parameter if provided
        selected_module = request.args.get('module')
        return render_template('scan.html', modules=manager.get_available_modules(), selected_module=selected_module)
    
    # Process POST request (scan submission)
    data = request.form.to_dict()
    
    # Extract module selection
    selected_modules = request.form.getlist('modules')
    if 'all' in selected_modules:
        selected_modules = manager.get_available_modules()
    elif not selected_modules:  # If no modules selected, use all modules
        selected_modules = manager.get_available_modules()
    
    # Extract target information
    target = data.get('target', '')
    api_key = data.get('api_key', '')
    
    # Validate inputs
    if not target:
        return jsonify({"error": "Target is required"}), 400
    
    # Run selected modules
    results = {}
    for module in selected_modules:
        try:
            # Configure module-specific parameters
            if module == "prompt_injection":
                module_params = {"target_api": target, "api_key": api_key}
            elif module == "model_robustness":
                # Simplified for web demo - in production would need file upload
                module_params = {
                    "model": "SIMULATED_MODEL",
                    "test_data": "SIMULATED_TEST_DATA",
                    "epsilon": 0.1
                }
            elif module == "privacy":
                module_params = {"target_api": target, "api_key": api_key}
            elif module == "cross_model":
                # Simplified for web demo
                module_params = {
                    "models": {
                        "tensorflow": "SIMULATED_TF_MODEL",
                        "pytorch": "SIMULATED_TORCH_MODEL"
                    }
                }
            elif module == "mlops":
                # Simplified for web demo
                module_params = {
                    "pipeline_config": {
                        "name": target,
                        "authentication": {"enabled": False},
                        "logging": {"enabled": True},
                        "data": {"encryption": {"enabled": False}},
                        "deployment": {"https": {"enabled": True}}
                    }
                }
            else:
                module_params = {"target_api": target}
            
            # Run the module and store results
            results[module] = manager.run_module(module, **module_params)
        except Exception as e:
            logger.error(f"Error running {module} module: {str(e)}")
            results[module] = {"error": str(e)}
    
    # Generate report
    scan_id = len(scan_history) + 1
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    report = {
        "id": scan_id,
        "timestamp": timestamp,
        "target": target,
        "modules": selected_modules,
        "summary": {
            "total_modules": len(selected_modules),
        },
        "results": results
    }
    
    # Add to history
    scan_history.append(report)
    
    # Redirect to results page
    return redirect(url_for('scan_result', scan_id=scan_id))

@app.route('/scan_result/<int:scan_id>')
def scan_result(scan_id):
    """Display scan results."""
    if scan_id < 1 or scan_id > len(scan_history):
        return jsonify({"error": "Scan not found"}), 404
    
    report = scan_history[scan_id - 1]
    return render_template('scan_result.html', report=report)

@app.route('/api/scan', methods=['POST'])
def api_scan():
    """API endpoint for scans."""
    data = request.json
    
    if not data:
        return jsonify({"error": "No data provided"}), 400
    
    target = data.get('target', '')
    api_key = data.get('api_key', '')
    selected_modules = data.get('modules', ['all'])
    
    if 'all' in selected_modules:
        selected_modules = manager.get_available_modules()
    
    if not target:
        return jsonify({"error": "Target is required"}), 400
    
    # Run selected modules (similar to scan route)
    results = {}
    for module in selected_modules:
        try:
            module_params = {"target_api": target, "api_key": api_key}
            results[module] = manager.run_module(module, **module_params)
        except Exception as e:
            results[module] = {"error": str(e)}
    
    # Generate report
    report = {
        "target": target,
        "modules": selected_modules,
        "results": results
    }
    
    return jsonify(report)

@app.route('/history')
def history():
    """Display scan history."""
    return render_template('history.html', history=scan_history)

@app.route('/api/history')
def api_history():
    """API endpoint for scan history."""
    return jsonify(scan_history)

@app.route('/about')
def about():
    """Display about page."""
    return render_template('about.html')

def main():
    """Run the web dashboard."""
    app.run(debug=True, host='0.0.0.0', port=8080)

if __name__ == '__main__':
    main()
