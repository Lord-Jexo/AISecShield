"""
Utilities for generating and formatting reports.
"""
from typing import Dict, List, Any, Optional
import json
import datetime
import os

def generate_report(
    results: Dict[str, Any],
    output_format: str = "json",
    output_file: Optional[str] = None
) -> Any:
    """
    Generate a formatted report from scan results.
    
    Args:
        results: Scan results to format
        output_format: Format for the report ('json', 'html', etc.)
        output_file: Path to save the report, or None to return as string
        
    Returns:
        Formatted report if output_file is None, otherwise None
    """
    # Add timestamp and metadata
    report = {
        "timestamp": datetime.datetime.now().isoformat(),
        "aisecshield_version": "0.1.0",  # Would come from version info in real implementation
        "results": results
    }
    
    # Generate summary statistics
    summary = {
        "modules_run": len(results),
        "vulnerability_counts": {}
    }
    
    # Count vulnerabilities by severity
    severity_counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}
    
    for module_name, module_results in results.items():
        vulnerabilities = module_results.get("vulnerabilities", [])
        
        for vulnerability in vulnerabilities:
            severity = vulnerability.get("severity", "unknown")
            if severity in severity_counts:
                severity_counts[severity] += 1
    
    summary["vulnerability_counts"] = severity_counts
    summary["total_vulnerabilities"] = sum(severity_counts.values())
    
    # Calculate risk score (simplified version)
    weights = {"critical": 10, "high": 5, "medium": 2, "low": 1}
    risk_score = sum(count * weights.get(severity, 0) for severity, count in severity_counts.items())
    summary["risk_score"] = risk_score
    
    # Determine overall risk level
    if risk_score > 50 or severity_counts["critical"] > 0:
        summary["risk_level"] = "critical"
    elif risk_score > 25 or severity_counts["high"] > 0:
        summary["risk_level"] = "high"
    elif risk_score > 10 or severity_counts["medium"] > 0:
        summary["risk_level"] = "medium"
    else:
        summary["risk_level"] = "low"
    
    # Add summary to report
    report["summary"] = summary
    
    # Format output
    if output_format == "json":
        formatted_report = json.dumps(report, indent=2)
    elif output_format == "html":
        # This would be a proper HTML template in a real implementation
        formatted_report = f"<html><body><pre>{json.dumps(report, indent=2)}</pre></body></html>"
    else:
        raise ValueError(f"Unsupported output format: {output_format}")
    
    # Save to file if requested
    if output_file:
        os.makedirs(os.path.dirname(os.path.abspath(output_file)), exist_ok=True)
        with open(output_file, 'w') as f:
            f.write(formatted_report)
        return None
    
    # Otherwise return the formatted report
    return formatted_report

def format_vulnerability_table(vulnerabilities: List[Dict[str, Any]]) -> str:
    """
    Format vulnerabilities as a table for terminal output.
    
    Args:
        vulnerabilities: List of vulnerability dictionaries
        
    Returns:
        Formatted table as string
    """
    if not vulnerabilities:
        return "No vulnerabilities found."
    
    # Define column widths
    cols = {
        "severity": 10,
        "message": 50,
        "details": 30
    }
    
    # Create header
    header = f"{'SEVERITY':<{cols['severity']}} | {'MESSAGE':<{cols['message']}} | {'DETAILS':<{cols['details']}}"
    separator = "-" * (cols["severity"] + cols["message"] + cols["details"] + 4)
    
    # Create rows
    rows = [header, separator]
    
    for vuln in vulnerabilities:
        severity = vuln.get("severity", "unknown").upper()
        message = vuln.get("message", "No message")
        
        # Truncate message if too long
        if len(message) > cols["message"] - 3:
            message = message[:cols["message"] - 3] + "..."
        
        # Format details
        details = vuln.get("details", {})
        details_str = ", ".join(f"{k}={v}" for k, v in details.items() if k not in ["message", "severity"])
        
        # Truncate details if too long
        if len(details_str) > cols["details"] - 3:
            details_str = details_str[:cols["details"] - 3] + "..."
        
        # Add row
        row = f"{severity:<{cols['severity']}} | {message:<{cols['message']}} | {details_str:<{cols['details']}}"
        rows.append(row)
    
    return "\n".join(rows)

def get_recommendation(
    vulnerability: Dict[str, Any]
) -> str:
    """
    Generate a recommendation for addressing a vulnerability.
    
    Args:
        vulnerability: Vulnerability dictionary
        
    Returns:
        Recommendation string
    """
    # Get vulnerability details
    severity = vulnerability.get("severity", "unknown")
    vulnerability_type = vulnerability.get("type", "unknown")
    details = vulnerability.get("details", {})
    
    # Get recommendation from details if available
    if "recommendation" in details:
        return details["recommendation"]
    
    # Generate recommendation based on type and severity
    recommendations = {
        "prompt_injection": "Implement better input validation and filtering for user prompts.",
        "model_robustness": "Train your model with adversarial examples to improve resilience.",
        "privacy": "Implement stronger privacy controls and data minimization practices.",
        "serialization": "Use secure deserialization practices and validate all inputs.",
        "data_leak": "Review model training procedures to prevent memorization of sensitive data.",
        "authentication": "Implement proper authentication for all API endpoints.",
        "encryption": "Enable encryption for all sensitive data in transit and at rest."
    }
    
    # Return specific recommendation or default
    return recommendations.get(
        vulnerability_type,
        f"Address this {severity} vulnerability according to security best practices."
    )
