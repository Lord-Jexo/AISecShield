"""
Scanner for detecting vulnerabilities across different model frameworks.
"""
from typing import Any, Dict, List, Optional, Union
from ...core.scanner import BaseScanner

class CrossModelAnalyzer(BaseScanner):
    """Scanner for detecting vulnerabilities across different model frameworks."""
    
    def __init__(
        self,
        models: Dict[str, Any],
        test_data: Optional[Any] = None,
        **kwargs
    ):
        """
        Initialize the cross-model analyzer.
        
        Args:
            models: Dictionary mapping framework names to model instances
            test_data: Test dataset to use for vulnerability detection
            **kwargs: Additional arguments passed to BaseScanner
        """
        super().__init__(**kwargs)
        self.models = models
        self.test_data = test_data
        
    def scan(self) -> Dict[str, Any]:
        """
        Execute the cross-model vulnerability scan.
        
        Returns:
            Dict containing scan results
        """
        if not self.models:
            self._log_issue(
                severity="critical",
                message="No models provided for cross-model analysis"
            )
            return {
                "module": "cross_model_analyzer",
                "error": "No models provided",
                "vulnerabilities": []
            }
        
        self.logger.info(f"Starting cross-model analysis across {len(self.models)} models")
        
        # Analyze common vulnerabilities
        model_results = {}
        for framework, model in self.models.items():
            model_results[framework] = self._analyze_model(framework, model)
        
        # Find similarities in vulnerabilities
        common_vulnerabilities = self._find_common_vulnerabilities(model_results)
        
        # Generate cross-model report
        return {
            "module": "cross_model_analyzer",
            "model_count": len(self.models),
            "frameworks_analyzed": list(self.models.keys()),
            "model_results": model_results,
            "common_vulnerabilities": common_vulnerabilities,
            "vulnerabilities": self.results
        }
    
    def _analyze_model(self, framework: str, model: Any) -> Dict[str, Any]:
        """
        Analyze a specific model for vulnerabilities.
        
        Args:
            framework: Name of the model framework
            model: Model instance to analyze
            
        Returns:
            Analysis results for the model
        """
        self.logger.info(f"Analyzing {framework} model")
        
        # This is a stub - in a real implementation, you would perform actual analysis
        
        # Simulated vulnerabilities by framework
        vulnerabilities = []
        
        if framework.lower() == "tensorflow":
            vulnerabilities = [
                {"type": "serialization", "severity": "medium", "description": "Unsafe model deserialization"},
                {"type": "memory", "severity": "low", "description": "Memory leak in graph execution"}
            ]
        elif framework.lower() == "pytorch":
            vulnerabilities = [
                {"type": "serialization", "severity": "medium", "description": "Pickle deserialization vulnerability"},
                {"type": "cuda", "severity": "low", "description": "CUDA memory handling issue"}
            ]
        elif framework.lower() == "sklearn":
            vulnerabilities = [
                {"type": "serialization", "severity": "medium", "description": "Joblib deserialization vulnerability"}
            ]
        else:
            vulnerabilities = [
                {"type": "unknown", "severity": "low", "description": "Framework-specific vulnerabilities unknown"}
            ]
        
        # Log issues
        for vuln in vulnerabilities:
            if vuln["severity"] in ["medium", "high", "critical"]:
                self._log_issue(
                    severity=vuln["severity"],
                    message=f"{framework} vulnerability: {vuln['description']}",
                    details={"framework": framework, "vulnerability": vuln}
                )
        
        return {
            "framework": framework,
            "vulnerabilities": vulnerabilities,
            "vulnerability_count": len(vulnerabilities)
        }
    
    def _find_common_vulnerabilities(self, model_results: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Find vulnerabilities common across multiple frameworks.
        
        Args:
            model_results: Results from individual model analyses
            
        Returns:
            List of common vulnerabilities
        """
        # Extract vulnerability types from all models
        vulnerability_types = {}
        
        for framework, result in model_results.items():
            for vuln in result["vulnerabilities"]:
                vuln_type = vuln["type"]
                if vuln_type not in vulnerability_types:
                    vulnerability_types[vuln_type] = {"frameworks": [], "descriptions": [], "severities": []}
                
                vulnerability_types[vuln_type]["frameworks"].append(framework)
                vulnerability_types[vuln_type]["descriptions"].append(vuln["description"])
                vulnerability_types[vuln_type]["severities"].append(vuln["severity"])
        
        # Identify types that appear in multiple frameworks
        common_vulnerabilities = []
        
        for vuln_type, data in vulnerability_types.items():
            if len(data["frameworks"]) > 1:
                # If this vulnerability appears in multiple frameworks, it's common
                severity = max(data["severities"], key=lambda s: {"low": 1, "medium": 2, "high": 3, "critical": 4}.get(s, 0))
                
                common_vuln = {
                    "type": vuln_type,
                    "severity": severity,
                    "frameworks": data["frameworks"],
                    "descriptions": data["descriptions"]
                }
                
                common_vulnerabilities.append(common_vuln)
                
                # Log the common vulnerability
                self._log_issue(
                    severity=severity,
                    message=f"Common vulnerability found across {', '.join(data['frameworks'])}: {vuln_type}",
                    details=common_vuln
                )
        
        return common_vulnerabilities
