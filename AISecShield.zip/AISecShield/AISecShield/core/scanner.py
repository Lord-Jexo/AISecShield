"""
Base scanner class that all vulnerability scanners inherit from.
"""
from typing import Any, Dict, List, Optional, Union
import logging

class BaseScanner:
    """Base class for all vulnerability scanners in AISecShield."""
    
    def __init__(self, target_model: Optional[Any] = None, config: Optional[Dict[str, Any]] = None):
        """
        Initialize the base scanner.
        
        Args:
            target_model: The AI model or API endpoint to scan
            config: Configuration parameters for the scanner
        """
        self.target_model = target_model
        self.config = config or {}
        self.results: List[Dict[str, Any]] = []
        self.logger = logging.getLogger(self.__class__.__name__)
    
    def scan(self) -> Dict[str, Any]:
        """
        Execute the vulnerability scan.
        
        Returns:
            Dict containing scan results
        
        Raises:
            NotImplementedError: This method must be implemented by subclasses
        """
        raise NotImplementedError("Subclasses must implement scan method")
    
    def report(self) -> Dict[str, Any]:
        """
        Generate a report of the scan results.
        
        Returns:
            Dict containing formatted scan results
        """
        return {
            "scanner": self.__class__.__name__,
            "target": str(self.target_model),
            "results": self.results,
            "total_issues": len(self.results)
        }
    
    def _log_issue(self, severity: str, message: str, details: Optional[Dict[str, Any]] = None) -> None:
        """
        Log a security issue found during scanning.
        
        Args:
            severity: How severe the issue is ('low', 'medium', 'high', 'critical')
            message: Description of the issue
            details: Additional information about the issue
        """
        issue = {
            "severity": severity,
            "message": message,
            "details": details or {}
        }
        self.results.append(issue)
        
        # Log based on severity
        if severity == "critical":
            self.logger.critical(message)
        elif severity == "high":
            self.logger.error(message)
        elif severity == "medium":
            self.logger.warning(message)
        else:
            self.logger.info(message)
