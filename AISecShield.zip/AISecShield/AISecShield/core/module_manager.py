"""
Module manager for handling different vulnerability scanning modules.
"""
from typing import Any, Dict, List, Type, Optional
import logging
from .scanner import BaseScanner

class ModuleManager:
    """
    Manages and orchestrates different vulnerability scanning modules.
    """
    
    def __init__(self):
        """Initialize the module manager."""
        self.modules: Dict[str, Type[BaseScanner]] = {}
        self.scan_results: Dict[str, Dict[str, Any]] = {}
        self.logger = logging.getLogger("ModuleManager")
    
    def register_module(self, name: str, module_class: Type[BaseScanner]) -> None:
        """
        Register a scanner module with the manager.
        
        Args:
            name: Unique name for the module
            module_class: Class reference for the scanner
        """
        if name in self.modules:
            self.logger.warning(f"Overwriting existing module: {name}")
        
        self.modules[name] = module_class
        self.logger.info(f"Registered module: {name}")
    
    def get_available_modules(self) -> List[str]:
        """
        Get list of available module names.
        
        Returns:
            List of registered module names
        """
        return list(self.modules.keys())
    
    def run_module(self, name: str, **kwargs) -> Dict[str, Any]:
        """
        Run a specific module by name.
        
        Args:
            name: Name of the module to run
            **kwargs: Arguments to pass to the scanner
            
        Returns:
            Scan results from the module
            
        Raises:
            ValueError: If module name is not found
        """
        if name not in self.modules:
            raise ValueError(f"Module '{name}' not found. Available modules: {', '.join(self.get_available_modules())}")
        
        self.logger.info(f"Running module: {name}")
        module = self.modules[name](**kwargs)
        result = module.scan()
        self.scan_results[name] = result
        
        return result
    
    def run_all_modules(self, **kwargs) -> Dict[str, Dict[str, Any]]:
        """
        Run all registered modules.
        
        Args:
            **kwargs: Arguments to pass to all scanners
            
        Returns:
            Dictionary of results from all modules
        """
        self.logger.info(f"Running all {len(self.modules)} modules")
        
        for name, module_class in self.modules.items():
            try:
                self.run_module(name, **kwargs)
            except Exception as e:
                self.logger.error(f"Error running module {name}: {str(e)}")
                self.scan_results[name] = {"error": str(e)}
        
        return self.scan_results
    
    def generate_report(self, output_format: str = "dict") -> Dict[str, Any]:
        """
        Generate consolidated report from all scan results.
        
        Args:
            output_format: Format for the report ('dict', 'json', etc.)
            
        Returns:
            Consolidated report with results from all modules
        """
        report = {
            "summary": {
                "total_modules": len(self.modules),
                "modules_run": len(self.scan_results),
                "timestamp": "TIMESTAMP_PLACEHOLDER",  # Would use datetime in real implementation
            },
            "results": self.scan_results
        }
        
        # For now only dict format is implemented
        return report
