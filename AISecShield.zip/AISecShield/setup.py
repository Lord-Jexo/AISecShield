from setuptools import setup, find_packages

setup(
    name="aisecshield",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "tensorflow>=2.8.0",
        "torch>=1.10.0",
        "scikit-learn>=1.0.0",
        "pandas>=1.3.0",
        "numpy>=1.20.0",
        "flask>=2.0.0",
        "requests>=2.26.0",
    ],
    entry_points={
        "console_scripts": [
            "aisecshield=AISecShield.interface.cli:main",
            "aisecshield-web=AISecShield.interface.web_dashboard.app:main",
        ],
    },
    author="Jexo",
    description="Comprehensive AI Security Testing Framework",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/Lord-Jexo/AISecShield",
    python_requires=">=3.9",
)